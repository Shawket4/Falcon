// ignore_for_file: file_names

import 'package:flutter/material.dart';

class TransporterProfileDetails extends StatefulWidget {
  const TransporterProfileDetails({Key? key}) : super(key: key);

  @override
  State<TransporterProfileDetails> createState() =>
      _TransporterProfileDetailsState();
}

class _TransporterProfileDetailsState extends State<TransporterProfileDetails> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
