// ignore_for_file: constant_identifier_names, non_constant_identifier_names, unused_local_variable

import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:dio/dio.dart';
import 'package:falcon_1/Screens/ApproveRequest.dart';
import 'package:falcon_1/Screens/CarProgressScreen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_image_compress/flutter_image_compress.dart';
import 'package:lottie/lottie.dart';
import 'Screens/Login.dart';

const String SERVER_IP = 'http://92.205.60.182:3001';
// const String SERVER_IP = 'http://localhost:3001';
// const SERVER_IP = 'http://localhost:3001/api';
// const SERVER_IP = 'http://92.205.60.182:3001/api';

void main() {
  runApp(const MainWidget());
}

int? CurrentIndex = 0;

Future<Uint8List?> CompressFile(File file) async {
  final result = await FlutterImageCompress.compressWithFile(
    file.absolute.path,
    quality: 30,
  );
  return result;
}

String permission = "";
String name = "";

Future<Object> getPermission(String jwt) async {
  Dio dio = Dio();
  dio.options.headers["Cookie"] = "jwt=$jwt";
  dio.options.headers["Content-Type"] = "application/json";
  var res = await dio.post("$SERVER_IP/api/user").then((response) {
    var str = response.data;
    permission = str["permission"].toString();
    name = str["name"];
  });
  return {
    "permission": permission,
    "name": name,
  };
}

Future<String> get jwtOrEmpty async {
  var jwt = await storage.read(key: "jwt");
  if (jwt == null) {
    await storage.delete(key: "jwt");
    return "";
  }
  var jwt2 = jsonDecode((jwt))["jwt"].toString();
  Dio dio = Dio();
  dio.options.headers["Cookie"] = "jwt=$jwt2";
  dio.options.headers["Content-Type"] = "application/json";
  var res = await dio.post("$SERVER_IP/api/user").then((response) async {
    var str = response.data;
    if (response.statusCode == 401) {
      await storage.delete(key: "jwt");
    }
    permission = str["permission"].toString();
    name = str["name"];
  });
  return jwt;
}

class Palette {
  static const MaterialColor primarySwatch = MaterialColor(
    0xFF183BA0, // 0% comes in here, this will be color picked if no shade is selected when defining a Color property which doesn’t require a swatch.
    <int, Color>{
      50: Color(0xFF2f4faa), //10%
      100: Color(0xFF4662b3), //20%
      200: Color(0xFF5d76bd), //30%
      300: Color(0xFF7489c6), //40%
      400: Color(0xFF8c9dd0), //50%
      500: Color(0xFFa3b1d9), //60%
      600: Color(0xFFbac4e3), //70%
      700: Color(0xFFd1d8ec), //80%
      800: Color(0xFFe8ebf6), //90%
      900: Color(0xFFffffff), //100%
    },
  );
}

class MainWidget extends StatelessWidget {
  const MainWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Authentication Demo',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Palette.primarySwatch,
        primaryColor: const Color(0xFF183BA0),
      ),
      home: FutureBuilder(
          future: jwtOrEmpty,
          builder: (context, snapshot) {
            if (!snapshot.hasData) {
              return Scaffold(
                body: Center(
                  // Display lottie animation
                  child: Lottie.asset(
                    "lottie/SplashScreen.json",
                    height: 200,
                    width: 200,
                  ),
                ),
              );
            }
            if (snapshot.data != "") {
              var str = snapshot.data.toString();
              var jwt = jsonDecode(str)["jwt"];
              // var jwt = jsonDecode(str)["jwt"];
              if (jwt.length < 3) {
                return const LoginScreen();
              } else {
                // var payload = json.decode(utf8.decode(jwt.codeUnits));
                return FutureBuilder(
                    future: getPermission(jwt),
                    builder: (context, snapshot) {
                      if (!snapshot.hasData) {
                        return Scaffold(
                          body: Center(
                            // Display lottie animation
                            child: Lottie.asset(
                              "lottie/SplashScreen.json",
                              height: 200,
                              width: 200,
                            ),
                          ),
                        );
                      }
                      // var data =
                      //     json.decode(json.encode(snapshot.data.toString()));
                      // print(data);
                      if (int.parse(permission) >= 3) {
                        return ApproveRequestScreen(
                          jwt: jwt.toString(),
                        );
                      } else if (int.parse(permission) == 2 ||
                          int.parse(permission) == 1) {
                        // print(snapshot.data);
                        return CarProgressScreen(
                          jwt: jwt.toString(),
                        );
                      } else {
                        return const LoginScreen();
                      }
                      //
                    });
              }
            } else {
              return const LoginScreen();
            }
          }),
    );
  }
}
